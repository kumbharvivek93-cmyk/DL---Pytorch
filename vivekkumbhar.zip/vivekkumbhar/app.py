import os
print(os.getcwd())
files=['templates','static','instance']
for i in files:
    os.makedirs(i,exist_ok=True)